# mariadb

MariaDB relational database

## TL;DR

```bash
helm repo add kubelauncher https://kubelauncher.github.io/charts
helm install my-mariadb kubelauncher/mariadb \
  --set auth.rootPassword=secret
```

Or via OCI:

```bash
helm install my-mariadb oci://ghcr.io/kubelauncher/charts/mariadb \
  --set auth.rootPassword=secret
```

## Introduction

This chart deploys MariaDB on Kubernetes using the [kubelauncher/mariadb](https://github.com/kubelauncher/docker) Docker image. It supports standalone and replication architectures.

The values structure follows the same conventions as popular community charts, allowing easy migration.

## Architecture

### Standalone (default)

A single MariaDB instance. Suitable for development and small production workloads.

```bash
helm install my-mariadb kubelauncher/mariadb \
  --set auth.rootPassword=secret \
  --set auth.username=myuser \
  --set auth.password=mypass \
  --set auth.database=mydb
```

### Replication

One primary with multiple secondaries using GTID-based replication. Secondaries serve read-only queries and provide data redundancy.

```bash
helm install my-mariadb kubelauncher/mariadb \
  --set architecture=replication \
  --set auth.rootPassword=secret \
  --set auth.replicationUser=replicator \
  --set auth.replicationPassword=replsecret \
  --set secondary.replicaCount=2
```

The primary enables binary logging and creates a dedicated replication user. Secondaries connect via `MASTER_USE_GTID=slave_pos` for position-based replication.

## Installing the Chart

```bash
helm repo add kubelauncher https://kubelauncher.github.io/charts
helm install my-mariadb kubelauncher/mariadb \
  --set auth.rootPassword=secret \
  --set auth.username=myuser \
  --set auth.password=mypass \
  --set auth.database=mydb
```

Or via OCI:

```bash
helm install my-mariadb oci://ghcr.io/kubelauncher/charts/mariadb \
  --set auth.rootPassword=secret \
  --set auth.username=myuser \
  --set auth.password=mypass \
  --set auth.database=mydb
```

## Uninstalling the Chart

```bash
helm uninstall my-mariadb
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| architecture | string | `"standalone"` |  |
| auth.database | string | `""` |  |
| auth.existingSecret | string | `""` |  |
| auth.password | string | `""` |  |
| auth.rootPassword | string | `""` |  |
| auth.secretKeys.rootPasswordKey | string | `"mariadb-root-password"` |  |
| auth.secretKeys.userPasswordKey | string | `"mariadb-password"` |  |
| auth.username | string | `""` |  |
| clusterDomain | string | `"cluster.local"` |  |
| commonAnnotations | object | `{}` |  |
| commonLabels | object | `{}` |  |
| enableServiceLinks | bool | `false` |  |
| extraDeploy | list | `[]` |  |
| fullnameOverride | string | `""` |  |
| global.defaultStorageClass | string | `""` |  |
| global.imagePullSecrets | list | `[]` |  |
| global.imageRegistry | string | `""` |  |
| global.mariadb.auth.database | string | `""` |  |
| global.mariadb.auth.existingSecret | string | `""` |  |
| global.mariadb.auth.password | string | `""` |  |
| global.mariadb.auth.rootPassword | string | `""` |  |
| global.mariadb.auth.username | string | `""` |  |
| global.mariadb.service.ports.mariadb | string | `""` |  |
| global.storageClass | string | `""` |  |
| image.digest | string | `"sha256:e78080afd12c6df238b1b9c6cc88882aa08ae2d595d9e483c278ddbae22c4afa"` |  |
| image.pullPolicy | string | `"Always"` |  |
| image.pullSecrets | list | `[]` |  |
| image.registry | string | `"ghcr.io"` |  |
| image.repository | string | `"kubelauncher/mariadb"` |  |
| image.tag | string | `"13.0.2"` |  |
| metrics.containerPorts.metrics | int | `9104` |  |
| metrics.enabled | bool | `false` |  |
| metrics.image.pullPolicy | string | `"Always"` |  |
| metrics.image.registry | string | `"ghcr.io"` |  |
| metrics.image.repository | string | `"kubelauncher/mysqld-exporter"` |  |
| metrics.image.tag | string | `"0.18.0"` |  |
| metrics.serviceMonitor.enabled | bool | `false` |  |
| metrics.serviceMonitor.interval | string | `""` |  |
| metrics.serviceMonitor.labels | object | `{}` |  |
| metrics.serviceMonitor.scrapeTimeout | string | `""` |  |
| nameOverride | string | `""` |  |
| namespaceOverride | string | `""` |  |
| networkPolicy.additionalRules | list | `[]` |  |
| networkPolicy.allowExternal | bool | `true` |  |
| networkPolicy.enabled | bool | `false` |  |
| primary.affinity | object | `{}` |  |
| primary.configuration | string | `""` |  |
| primary.containerPorts.mariadb | int | `3306` |  |
| primary.containerSecurityContext.allowPrivilegeEscalation | bool | `false` |  |
| primary.containerSecurityContext.capabilities.drop[0] | string | `"ALL"` |  |
| primary.containerSecurityContext.enabled | bool | `true` |  |
| primary.containerSecurityContext.readOnlyRootFilesystem | bool | `false` |  |
| primary.containerSecurityContext.runAsGroup | int | `1001` |  |
| primary.containerSecurityContext.runAsNonRoot | bool | `true` |  |
| primary.containerSecurityContext.runAsUser | int | `1001` |  |
| primary.containerSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| primary.extraEnvVars | list | `[]` |  |
| primary.extraVolumeMounts | list | `[]` |  |
| primary.extraVolumes | list | `[]` |  |
| primary.initContainers | list | `[]` |  |
| primary.livenessProbe.enabled | bool | `true` |  |
| primary.livenessProbe.failureThreshold | int | `6` |  |
| primary.livenessProbe.initialDelaySeconds | int | `30` |  |
| primary.livenessProbe.periodSeconds | int | `10` |  |
| primary.livenessProbe.successThreshold | int | `1` |  |
| primary.livenessProbe.timeoutSeconds | int | `5` |  |
| primary.name | string | `"primary"` |  |
| primary.nodeSelector | object | `{}` |  |
| primary.persistence.accessModes[0] | string | `"ReadWriteOnce"` |  |
| primary.persistence.annotations | object | `{}` |  |
| primary.persistence.enabled | bool | `true` |  |
| primary.persistence.existingClaim | string | `""` |  |
| primary.persistence.labels | object | `{}` |  |
| primary.persistence.mountPath | string | `"/data/mariadb"` |  |
| primary.persistence.size | string | `"8Gi"` |  |
| primary.persistence.storageClass | string | `""` |  |
| primary.podAnnotations | object | `{}` |  |
| primary.podLabels | object | `{}` |  |
| primary.podSecurityContext.enabled | bool | `true` |  |
| primary.podSecurityContext.fsGroup | int | `1001` |  |
| primary.readinessProbe.enabled | bool | `true` |  |
| primary.readinessProbe.failureThreshold | int | `6` |  |
| primary.readinessProbe.initialDelaySeconds | int | `5` |  |
| primary.readinessProbe.periodSeconds | int | `10` |  |
| primary.readinessProbe.successThreshold | int | `1` |  |
| primary.readinessProbe.timeoutSeconds | int | `5` |  |
| primary.replicaCount | int | `1` |  |
| primary.resources | object | `{}` |  |
| primary.resourcesPreset | string | `"micro"` |  |
| primary.service.annotations | object | `{}` |  |
| primary.service.clusterIP | string | `""` |  |
| primary.service.headless.annotations | object | `{}` |  |
| primary.service.labels | object | `{}` |  |
| primary.service.nodePorts.mariadb | string | `""` |  |
| primary.service.ports.mariadb | int | `3306` |  |
| primary.service.type | string | `"ClusterIP"` |  |
| primary.sidecars | list | `[]` |  |
| primary.startupProbe.enabled | bool | `true` |  |
| primary.startupProbe.failureThreshold | int | `30` |  |
| primary.startupProbe.initialDelaySeconds | int | `10` |  |
| primary.startupProbe.periodSeconds | int | `10` |  |
| primary.startupProbe.successThreshold | int | `1` |  |
| primary.startupProbe.timeoutSeconds | int | `5` |  |
| primary.tolerations | list | `[]` |  |
| replication.password | string | `""` |  |
| replication.user | string | `"replicator"` |  |
| secondary.affinity | object | `{}` |  |
| secondary.containerPorts.mariadb | int | `3306` |  |
| secondary.containerSecurityContext.allowPrivilegeEscalation | bool | `false` |  |
| secondary.containerSecurityContext.capabilities.drop[0] | string | `"ALL"` |  |
| secondary.containerSecurityContext.enabled | bool | `true` |  |
| secondary.containerSecurityContext.readOnlyRootFilesystem | bool | `false` |  |
| secondary.containerSecurityContext.runAsGroup | int | `1001` |  |
| secondary.containerSecurityContext.runAsNonRoot | bool | `true` |  |
| secondary.containerSecurityContext.runAsUser | int | `1001` |  |
| secondary.containerSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| secondary.extraEnvVars | list | `[]` |  |
| secondary.extraVolumeMounts | list | `[]` |  |
| secondary.extraVolumes | list | `[]` |  |
| secondary.initContainers | list | `[]` |  |
| secondary.livenessProbe.enabled | bool | `true` |  |
| secondary.livenessProbe.failureThreshold | int | `6` |  |
| secondary.livenessProbe.initialDelaySeconds | int | `30` |  |
| secondary.livenessProbe.periodSeconds | int | `10` |  |
| secondary.livenessProbe.successThreshold | int | `1` |  |
| secondary.livenessProbe.timeoutSeconds | int | `5` |  |
| secondary.nodeSelector | object | `{}` |  |
| secondary.persistence.accessModes[0] | string | `"ReadWriteOnce"` |  |
| secondary.persistence.annotations | object | `{}` |  |
| secondary.persistence.enabled | bool | `true` |  |
| secondary.persistence.existingClaim | string | `""` |  |
| secondary.persistence.labels | object | `{}` |  |
| secondary.persistence.mountPath | string | `"/data/mariadb"` |  |
| secondary.persistence.size | string | `"8Gi"` |  |
| secondary.persistence.storageClass | string | `""` |  |
| secondary.podAnnotations | object | `{}` |  |
| secondary.podLabels | object | `{}` |  |
| secondary.podSecurityContext.enabled | bool | `true` |  |
| secondary.podSecurityContext.fsGroup | int | `1001` |  |
| secondary.readinessProbe.enabled | bool | `true` |  |
| secondary.readinessProbe.failureThreshold | int | `6` |  |
| secondary.readinessProbe.initialDelaySeconds | int | `5` |  |
| secondary.readinessProbe.periodSeconds | int | `10` |  |
| secondary.readinessProbe.successThreshold | int | `1` |  |
| secondary.readinessProbe.timeoutSeconds | int | `5` |  |
| secondary.replicaCount | int | `2` |  |
| secondary.resources | object | `{}` |  |
| secondary.resourcesPreset | string | `"micro"` |  |
| secondary.service.annotations | object | `{}` |  |
| secondary.service.clusterIP | string | `""` |  |
| secondary.service.labels | object | `{}` |  |
| secondary.service.nodePorts.mariadb | string | `""` |  |
| secondary.service.ports.mariadb | int | `3306` |  |
| secondary.service.type | string | `"ClusterIP"` |  |
| secondary.sidecars | list | `[]` |  |
| secondary.startupProbe.enabled | bool | `true` |  |
| secondary.startupProbe.failureThreshold | int | `30` |  |
| secondary.startupProbe.initialDelaySeconds | int | `10` |  |
| secondary.startupProbe.periodSeconds | int | `10` |  |
| secondary.startupProbe.successThreshold | int | `1` |  |
| secondary.startupProbe.timeoutSeconds | int | `5` |  |
| secondary.tolerations | list | `[]` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.automountServiceAccountToken | bool | `false` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| kubelauncher | <platform@kubelauncher.com> | <https://www.kubelauncher.com> |
